import { useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import {
  AppWindow, BadgeCheck, ChevronDown, CheckCircle2, Clock, Copy, Crown, FileText,
  Flame, Gift, Home, Instagram, KeyRound, LogOut, Menu, MessageCircle, Music2, Phone, Search,
  Send, Settings, Share2, Shield, ShieldCheck, ShoppingCart, Smartphone, User, Users, Wallet,
  X, Youtube, Zap, Package, Timer,
} from 'lucide-react';

/* =====================================================================
   TIPE & DATA
   ===================================================================== */
type Screen = 'landing' | 'auth' | 'dashboard';
type AuthMode = 'login' | 'register';
type Tab = 'home' | 'sosmed' | 'nokos' | 'premium' | 'riwayat' | 'deposit' | 'affiliate' | 'profil' | 'setting';
type Category = 'Nokos OTP' | 'Suntik Sosmed' | 'Aplikasi Premium';

interface Item { id: string; name: string; category: Category; group: string; price: number; note?: string; }
interface UserRecord { username: string; passwordHash: string; createdAt: string; saldo: number; }
interface ToastState { type: 'ok' | 'err' | 'info'; msg: string; }

const USERS_KEY = 'nyxvo_users';
const SESSION_KEY = 'nyxvo_session';

/* Placeholder aset anime. Letakkan gambar Anda di folder /public/assets/ dengan nama sama.
   Jika file belum ada, otomatis tampil latar energi oranye (fallback). */
const ASSETS = {
  hero: '/assets/hero-anime.jpg',
  rank: '/assets/rank-anime.jpg',
  landing: '/assets/landing-anime.jpg',
  avatar: '/assets/avatar.jpg',
  promo: '/assets/promo-anime.jpg',
};

const NOKOS_RAW: [string, number, string?][] = [
  ['Nokos WhatsApp', 6000], ['Nokos Telegram', 7000, 'Tanya Stok'], ['Nokos DANA', 2000], ['Nokos OVO', 2500],
  ['Nokos GoPay', 2500], ['Nokos Gojek', 2500], ['Nokos Shopee', 4000], ['Nokos Tokopedia', 4000],
  ['Nokos Lazada', 3000], ['Nokos Bukalapak', 2000], ['Nokos Blibli', 1500], ['Nokos Tiktok', 3000],
  ['Nokos Facebook', 2500], ['Nokos Instagram', 2500], ['Nokos Gmail/Google', 2500], ['Nokos Twitter/X', 2500],
  ['Nokos Discord', 2000], ['Nokos WeChat', 1500], ['Nokos Line', 1500], ['Nokos KakaoTalk', 1500],
  ['Nokos Snapchat', 1500], ['Nokos Spotify', 1500], ['Nokos Netflix', 1500], ['Nokos ChatGPT', 2000],
];
const NOKOS: Item[] = NOKOS_RAW.map(([name, price, note], i) => ({
  id: `nokos-${i}`, name, price, note, category: 'Nokos OTP', group: 'Nokos OTP',
}));

const SOSMED_RAW: [string, string, number][] = [
  ['WhatsApp', 'Saluran WA 100', 1000], ['WhatsApp', 'Saluran WA 1000', 10000],
  ['Instagram', 'Followers IG 100', 5000], ['Instagram', 'Followers IG Indo 1000', 70000], ['Instagram', 'Like IG 1000', 10000],
  ['Tiktok', 'Followers Tiktok 1000', 30000], ['Tiktok', 'View Tiktok 5000', 13000],
  ['Youtube', 'Subscribers YT 1000', 111000],
  ['Telegram', 'Member Telegram 1000', 35000],
];
const SOSMED: Item[] = SOSMED_RAW.map(([group, name, price], i) => ({
  id: `sosmed-${i}`, name, price, group, category: 'Suntik Sosmed',
}));

const PREMIUM_RAW: [string, number][] = [
  ['Netflix Premium 1 Bulan', 15000], ['Canva Pro 1 Tahun', 25000], ['ChatGPT Plus 1 Bulan', 30000],
  ['Spotify Premium 1 Bulan', 10000], ['YouTube Premium 1 Bulan', 12000], ['CapCut Pro 1 Bulan', 15000],
];
const PREMIUM: Item[] = PREMIUM_RAW.map(([name, price], i) => ({
  id: `premium-${i}`, name, price, group: 'Aplikasi Premium', category: 'Aplikasi Premium',
}));

const ALL_ITEMS: Item[] = [...SOSMED, ...NOKOS, ...PREMIUM];

const POPULAR = [
  { name: 'Instagram Followers', from: 2500, color: 'border-orange-500/70 shadow-[0_0_18px_rgba(255,106,0,0.3)]', icon: <Instagram className="h-7 w-7 text-pink-400" /> },
  { name: 'TikTok Views', from: 1600, color: 'border-fuchsia-500/70 shadow-[0_0_18px_rgba(217,70,239,0.3)]', icon: <Music2 className="h-7 w-7 text-cyan-300" /> },
  { name: 'WhatsApp OTP', from: 1000, color: 'border-emerald-400/70 shadow-[0_0_18px_rgba(52,211,153,0.3)]', icon: <MessageCircle className="h-7 w-7 text-emerald-400" /> },
  { name: 'Telegram Members', from: 1500, color: 'border-sky-400/70 shadow-[0_0_18px_rgba(56,189,248,0.3)]', icon: <Send className="h-7 w-7 text-sky-400" /> },
];

const PAYMENTS = ['DANA', 'OVO', 'GoPay', 'LinkAja', 'QRIS', 'Bank Mandiri', 'BCA', 'BRI', 'BNI'];

const rupiah = (n: number): string => 'Rp ' + n.toLocaleString('id-ID');

/* =====================================================================
   LOCAL DATABASE (localStorage)
   ===================================================================== */
function readUsers(): UserRecord[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    return raw ? (JSON.parse(raw) as UserRecord[]) : [];
  } catch { return []; }
}
function writeUsers(users: UserRecord[]): void {
  try { localStorage.setItem(USERS_KEY, JSON.stringify(users)); } catch { /* storage penuh/diblokir */ }
}
async function hashPassword(pw: string): Promise<string> {
  try {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('nyxvo::' + pw));
      return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
    }
  } catch { /* fallback di bawah */ }
  return 'plain::' + pw;
}

/* =====================================================================
   KOMPONEN KECIL
   ===================================================================== */
const neonBox = 'border border-orange-500/50 shadow-[0_0_20px_rgba(255,106,0,0.18)]';
const glass = 'bg-white/[0.03] backdrop-blur-md border border-white/10';
const btnOrange = 'rounded-lg bg-gradient-to-b from-orange-500 to-orange-700 font-bold text-white shadow-[0_0_14px_rgba(255,106,0,0.55)] transition hover:brightness-125 focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-300';

function AnimeArt({ src, className = '', children }: { src: string; className?: string; children?: ReactNode }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_40%,rgba(255,90,0,0.65),transparent_55%),radial-gradient(circle_at_80%_20%,rgba(168,40,255,0.35),transparent_50%),linear-gradient(135deg,#1a0603,#0d0e12)]" />
      {src && !failed && (
        <img src={src} alt="" className="absolute inset-0 h-full w-full object-cover opacity-90" onError={() => setFailed(true)} />
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-black/10 via-black/20 to-black/60" />
      {children}
    </div>
  );
}

function Logo({ small = false }: { small?: boolean }) {
  return (
    <div className="leading-none">
      <div className={`${small ? 'text-xl' : 'text-2xl'} font-black italic tracking-tight text-white drop-shadow-[0_0_8px_rgba(255,106,0,0.8)]`}>NYXVO</div>
      <div className="text-[10px] font-bold italic tracking-[0.25em] text-orange-400">PROJECT</div>
    </div>
  );
}

function StatusBadge({ text = 'Tersedia' }: { text?: string }) {
  return <span className="rounded border border-emerald-400/50 bg-emerald-500/15 px-2 py-0.5 text-[11px] font-semibold text-emerald-300 shadow-[0_0_8px_rgba(16,185,129,0.4)]">{text}</span>;
}

function useCountUp(target: number, run: boolean): number {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!run) return;
    let frame = 0;
    const steps = 60;
    const id = window.setInterval(() => {
      frame += 1;
      setVal(Math.round(target * Math.min(1, frame / steps)));
      if (frame >= steps) window.clearInterval(id);
    }, 25);
    return () => window.clearInterval(id);
  }, [target, run]);
  return val;
}

/* =====================================================================
   APP
   ===================================================================== */
export default function App() {
  const [screen, setScreen] = useState<Screen>('landing');
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [currentUser, setCurrentUser] = useState<UserRecord | null>(null);
  const [tab, setTab] = useState<Tab>('home');
  const [query, setQuery] = useState('');
  const [cartCount, setCartCount] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() => (typeof window === 'undefined' ? true : window.innerWidth >= 1024));
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = (type: ToastState['type'], msg: string) => setToast({ type, msg });
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(id);
  }, [toast]);

  /* Authentication Guard: pulihkan sesi, dashboard hanya untuk user valid */
  useEffect(() => {
    try {
      const sess = localStorage.getItem(SESSION_KEY);
      if (sess) {
        const found = readUsers().find((u) => u.username === sess);
        if (found) { setCurrentUser(found); setScreen('dashboard'); }
        else localStorage.removeItem(SESSION_KEY);
      }
    } catch { /* abaikan */ }
  }, []);

  const activeScreen: Screen = screen === 'dashboard' && !currentUser ? 'landing' : screen;

  const goAuth = (mode: AuthMode) => { setAuthMode(mode); setScreen('auth'); };

  const handleLogout = () => {
    try { localStorage.removeItem(SESSION_KEY); } catch { /* abaikan */ }
    setCurrentUser(null); setQuery(''); setTab('home'); setCartCount(0); setScreen('landing');
  };

  /* ---------------------------------------------------------------
     PLACEHOLDER GATEWAY PEMBAYARAN (GETPAY / GATEPAY)
     Dipanggil oleh tombol DEPOSIT dan ORDER/BELI di seluruh aplikasi.
     CARA INTEGRASI NANTI:
       1. Ganti isi fungsi ini dengan fetch ke API URL gateway Anda, contoh:
          const res = await fetch('https://API-GATEWAY-ANDA/create-payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: 'Bearer API_KEY' },
            body: JSON.stringify({ item: item?.name, amount: item?.price, user: currentUser?.username }),
          });
       2. Arahkan user ke payment URL dari respons, lalu tangani callback/webhook di server.
       3. Jangan simpan API key di frontend; panggil lewat backend/serverless function.
     Parameter `item` kosong (undefined) berarti klik berasal dari tombol DEPOSIT.
     --------------------------------------------------------------- */
  const handleGetPayPayment = (item?: Item): void => {
    // TODO: sisipkan API URL gateway pembayaran di sini (lihat instruksi di atas).
    void item;
    showToast('info', 'Gateway pembayaran belum dihubungkan.');
  };

  const addToCart = (item: Item) => { setCartCount((c) => c + 1); showToast('ok', `${item.name} ditambahkan ke keranjang`); };

  const navigate = (t: Tab) => {
    setTab(t); setQuery('');
    if (typeof window !== 'undefined' && window.innerWidth < 1024) setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#070709] font-sans text-white">
      {toast && (
        <div role="status" className={`fixed right-4 top-4 z-[100] flex max-w-sm items-center gap-2 rounded-lg border px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur ${
          toast.type === 'ok' ? 'border-emerald-400/60 bg-emerald-950/90 text-emerald-200'
          : toast.type === 'err' ? 'border-red-400/60 bg-red-950/90 text-red-200'
          : 'border-orange-400/60 bg-[#1a0f05]/95 text-orange-200'}`}>
          {toast.type === 'ok' ? <CheckCircle2 className="h-4 w-4" /> : toast.type === 'err' ? <X className="h-4 w-4" /> : <Zap className="h-4 w-4" />}
          {toast.msg}
        </div>
      )}

      {activeScreen === 'landing' && <Landing onLogin={() => goAuth('login')} onRegister={() => goAuth('register')} />}
      {activeScreen === 'auth' && (
        <AuthScreen
          mode={authMode} setMode={setAuthMode} onBack={() => setScreen('landing')} showToast={showToast}
          onSuccess={(u) => { setCurrentUser(u); setScreen('dashboard'); setTab('home'); }}
        />
      )}
      {activeScreen === 'dashboard' && currentUser && (
        <Dashboard
          user={currentUser} tab={tab} navigate={navigate} query={query} setQuery={setQuery}
          cartCount={cartCount} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
          onLogout={handleLogout} onPay={handleGetPayPayment} onAddCart={addToCart} showToast={showToast}
        />
      )}
    </div>
  );
}

/* =====================================================================
   A. LANDING PAGE
   ===================================================================== */
function Landing({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) {
  const users = useCountUp(320024, true);
  const orders = useCountUp(5753306, true);
  const services = useCountUp(603, true);
  const [menuOpen, setMenuOpen] = useState(false);

  const scrollTo = (id: string) => { document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); setMenuOpen(false); };

  const why = [
    { icon: <Wallet className="h-7 w-7" />, title: 'Layanan Murah', text: 'Harga terjangkau untuk semua layanan sosmed, nomor OTP, dan aplikasi premium.' },
    { icon: <Zap className="h-7 w-7" />, title: 'Sistem Otomatis', text: 'Pesanan diproses otomatis oleh sistem dalam hitungan menit tanpa menunggu admin.' },
    { icon: <Clock className="h-7 w-7" />, title: 'Pelayanan Terbaik 24/7', text: 'Tim support siap membantu kapan saja, setiap hari sepanjang tahun.' },
  ];

  return (
    <div>
      <header className="sticky top-0 z-40 border-b border-orange-500/20 bg-[#070709]/85 backdrop-blur-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <Logo />
          <nav className="hidden items-center gap-8 text-sm font-semibold text-white/80 md:flex">
            <button onClick={() => scrollTo('utama')} className="hover:text-orange-400">Utama</button>
            <button onClick={() => scrollTo('layanan')} className="hover:text-orange-400">Layanan</button>
            <button onClick={() => scrollTo('kontak')} className="hover:text-orange-400">Kontak</button>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={onLogin} className="rounded-lg border border-orange-500/60 px-4 py-2 text-sm font-bold text-orange-300 hover:bg-orange-500/10">Masuk</button>
            <button onClick={onRegister} className={`${btnOrange} px-4 py-2 text-sm`}>Register</button>
            <button className="rounded-lg p-2 md:hidden" aria-label="Menu" onClick={() => setMenuOpen((v) => !v)}><Menu className="h-5 w-5" /></button>
          </div>
        </div>
        {menuOpen && (
          <div className="flex flex-col gap-1 border-t border-white/10 px-4 py-2 text-sm font-semibold md:hidden">
            <button className="py-2 text-left" onClick={() => scrollTo('utama')}>Utama</button>
            <button className="py-2 text-left" onClick={() => scrollTo('layanan')}>Layanan</button>
            <button className="py-2 text-left" onClick={() => scrollTo('kontak')}>Kontak</button>
          </div>
        )}
      </header>

      <section id="utama" className="mx-auto max-w-7xl px-4 pt-8">
        <AnimeArt src={ASSETS.landing} className={`rounded-2xl ${neonBox}`}>
          <div className="relative z-10 flex min-h-[420px] flex-col items-center justify-center px-6 py-14 text-center">
            <h1 className="text-4xl font-black italic leading-tight drop-shadow-[0_0_14px_rgba(255,106,0,0.9)] md:text-6xl">
              NYXVO PROJECT <span className="block text-orange-400">DIGITAL MARKET</span>
            </h1>
            <p className="mt-4 text-sm font-bold tracking-wide md:text-lg">SUNTIK ALL SOSMED • NOKOS OTP • APLIKASI PREMIUM</p>
            <p className="mt-2 text-xs font-bold tracking-wide text-orange-400 md:text-base">PROSES OTOMATIS • MURAH • CEPAT • AMAN</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <button onClick={onLogin} className={`${btnOrange} px-7 py-3`}>Masuk Sekarang</button>
              <button onClick={onRegister} className="rounded-lg border border-orange-400/70 bg-black/40 px-7 py-3 font-bold text-orange-300 backdrop-blur hover:bg-orange-500/15">Registrasi Member</button>
            </div>
          </div>
        </AnimeArt>

        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { v: users, l: 'Pengguna Aktif', i: <Users className="h-6 w-6" /> },
            { v: orders, l: 'Pesanan Dikerjakan', i: <Package className="h-6 w-6" /> },
            { v: services, l: 'Layanan Tersedia', i: <Zap className="h-6 w-6" /> },
          ].map((s) => (
            <div key={s.l} className={`${glass} flex items-center gap-4 rounded-xl p-5`}>
              <div className="rounded-lg bg-orange-500/15 p-3 text-orange-400">{s.i}</div>
              <div>
                <div className="text-2xl font-black text-orange-300">{s.v.toLocaleString('id-ID')}</div>
                <div className="text-sm text-white/70">{s.l}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="layanan" className="mx-auto max-w-7xl px-4 py-14">
        <h2 className="mb-8 text-center text-2xl font-black md:text-3xl">Kenapa Harus Kami?</h2>
        <div className="grid gap-5 md:grid-cols-3">
          {why.map((w) => (
            <div key={w.title} className={`${glass} rounded-xl p-6 transition hover:border-orange-500/60`}>
              <div className="mb-4 inline-flex rounded-lg bg-orange-500/15 p-3 text-orange-400">{w.icon}</div>
              <h3 className="text-lg font-bold">{w.title}</h3>
              <p className="mt-2 text-sm text-white/70">{w.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-14">
        <h2 className="mb-6 text-center text-xl font-black">Metode Pembayaran</h2>
        <div className="flex flex-wrap justify-center gap-3">
          {PAYMENTS.map((p) => (
            <span key={p} className="rounded-lg border border-white/15 bg-white/5 px-5 py-2 text-sm font-bold text-white/85">{p}</span>
          ))}
        </div>
      </section>

      <footer id="kontak" className="border-t border-orange-500/20 bg-[#0d0e12] px-4 py-8">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 md:flex-row">
          <Logo small />
          <div className="flex items-center gap-4 text-sm text-white/70">
            <span className="flex items-center gap-1"><Phone className="h-4 w-4 text-orange-400" /> Kontak via WhatsApp & Telegram</span>
          </div>
          <p className="text-xs text-white/50">© 2024 NYXVO PROJECT - All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
}

/* =====================================================================
   B. REGISTRASI & LOGIN
   ===================================================================== */
function AuthScreen({ mode, setMode, onBack, onSuccess, showToast }: {
  mode: AuthMode; setMode: (m: AuthMode) => void; onBack: () => void;
  onSuccess: (u: UserRecord) => void; showToast: (t: ToastState['type'], m: string) => void;
}) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const switchMode = (m: AuthMode) => { setMode(m); setError(''); setPassword(''); };

  const submit = async () => {
    setError('');
    const uname = username.trim();
    if (uname.length < 3) { setError('Username minimal 3 karakter.'); return; }
    if (!/^[A-Za-z0-9_.]+$/.test(uname)) { setError('Username hanya boleh huruf, angka, titik, dan underscore.'); return; }
    if (password.length < 6) { setError('Kata sandi minimal 6 karakter.'); return; }
    setBusy(true);
    const hash = await hashPassword(password);
    const users = readUsers();
    const found = users.find((u) => u.username.toLowerCase() === uname.toLowerCase());

    if (mode === 'register') {
      if (found) { setError('Username sudah terdaftar. Gunakan username lain.'); setBusy(false); return; }
      users.push({ username: uname, passwordHash: hash, createdAt: new Date().toISOString(), saldo: 125000 });
      writeUsers(users);
      showToast('ok', 'Registrasi berhasil! Silakan masuk.');
      setPassword(''); setMode('login'); setBusy(false);
      return;
    }

    if (!found) { setError('Username belum terdaftar. Silakan daftar terlebih dahulu.'); setBusy(false); return; }
    if (found.passwordHash !== hash) { setError('Kata sandi salah. Coba lagi.'); setBusy(false); return; }
    try { localStorage.setItem(SESSION_KEY, found.username); } catch { /* abaikan */ }
    showToast('ok', `Selamat datang, ${found.username}!`);
    setBusy(false);
    onSuccess(found);
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-10">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(255,90,0,0.22),transparent_60%)]" />
      <div className={`${glass} ${neonBox} relative w-full max-w-md rounded-2xl p-8`}>
        <button onClick={onBack} className="mb-4 text-sm text-white/60 hover:text-orange-300">← Kembali ke beranda</button>
        <div className="mb-6 flex justify-center"><Logo /></div>
        <h2 className="text-center text-2xl font-black">{mode === 'login' ? 'Masuk ke Akun' : 'Daftar Akun Baru'}</h2>
        <p className="mb-6 mt-1 text-center text-sm text-white/60">{mode === 'login' ? 'Masukkan username dan kata sandi Anda.' : 'Buat akun member untuk mulai berbelanja.'}</p>

        <div className="space-y-4">
          <label className="block">
            <span className="mb-1 block text-sm font-semibold">Nama Pengguna</span>
            <div className="flex items-center gap-2 rounded-lg border border-white/15 bg-black/40 px-3 focus-within:border-orange-500">
              <User className="h-4 w-4 text-orange-400" />
              <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" autoComplete="username"
                className="w-full bg-transparent py-3 text-sm outline-none placeholder:text-white/30" />
            </div>
          </label>
          <label className="block">
            <span className="mb-1 block text-sm font-semibold">Kata Sandi</span>
            <div className="flex items-center gap-2 rounded-lg border border-white/15 bg-black/40 px-3 focus-within:border-orange-500">
              <KeyRound className="h-4 w-4 text-orange-400" />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Kata sandi"
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                onKeyDown={(e) => { if (e.key === 'Enter') void submit(); }}
                className="w-full bg-transparent py-3 text-sm outline-none placeholder:text-white/30" />
            </div>
          </label>
          {error && <div role="alert" className="rounded-lg border border-red-500/50 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</div>}
          <button onClick={() => void submit()} disabled={busy} className={`${btnOrange} w-full py-3 disabled:opacity-60`}>
            {busy ? 'Memproses...' : mode === 'login' ? 'Masuk' : 'Daftar'}
          </button>
        </div>

        <p className="mt-6 text-center text-sm text-white/70">
          {mode === 'login' ? 'Belum punya akun? ' : 'Sudah punya akun? '}
          <button onClick={() => switchMode(mode === 'login' ? 'register' : 'login')} className="font-bold text-orange-400 hover:underline">
            {mode === 'login' ? 'Daftar' : 'Masuk'}
          </button>
        </p>
      </div>
    </div>
  );
}

/* =====================================================================
   C. DASHBOARD
   ===================================================================== */
interface DashProps {
  user: UserRecord; tab: Tab; navigate: (t: Tab) => void; query: string; setQuery: (q: string) => void;
  cartCount: number; sidebarOpen: boolean; setSidebarOpen: (v: boolean) => void; onLogout: () => void;
  onPay: (item?: Item) => void; onAddCart: (item: Item) => void; showToast: (t: ToastState['type'], m: string) => void;
}

function Dashboard(p: DashProps) {
  const { user, tab, navigate, query, setQuery, cartCount, sidebarOpen, setSidebarOpen, onLogout, onPay, onAddCart } = p;

  /* D. LIVE SEARCH — useMemo */
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return ALL_ITEMS.filter((i) => `${i.name} ${i.group} ${i.category}`.toLowerCase().includes(q));
  }, [query]);

  const groups: { title: string; items: { key: Tab | 'logout'; label: string; icon: ReactNode }[] }[] = [
    { title: 'LAYANAN', items: [
      { key: 'home', label: 'Beranda', icon: <Home className="h-5 w-5" /> },
      { key: 'sosmed', label: 'Suntik Sosmed', icon: <CheckCircle2 className="h-5 w-5" /> },
      { key: 'nokos', label: 'Nokos OTP', icon: <Smartphone className="h-5 w-5" /> },
      { key: 'premium', label: 'Aplikasi Premium', icon: <AppWindow className="h-5 w-5" /> },
    ] },
    { title: 'EXTRA', items: [
      { key: 'riwayat', label: 'Riwayat Pesanan', icon: <FileText className="h-5 w-5" /> },
      { key: 'deposit', label: 'Deposit Saldo', icon: <Wallet className="h-5 w-5" /> },
      { key: 'affiliate', label: 'Affiliate', icon: <Share2 className="h-5 w-5" /> },
    ] },
    { title: 'AKUN', items: [
      { key: 'profil', label: 'Profil Saya', icon: <User className="h-5 w-5" /> },
      { key: 'setting', label: 'Setting Akun', icon: <Settings className="h-5 w-5" /> },
      { key: 'logout', label: 'Logout', icon: <LogOut className="h-5 w-5" /> },
    ] },
  ];

  const initial = user.username.charAt(0).toUpperCase();

  let content: ReactNode;
  if (query.trim()) content = <SearchResults query={query} results={results} onPay={onPay} onAddCart={onAddCart} />;
  else if (tab === 'home') content = <HomePage user={user} navigate={navigate} onPay={onPay} onAddCart={onAddCart} setQuery={setQuery} />;
  else if (tab === 'nokos') content = <NokosPage onPay={onPay} onAddCart={onAddCart} />;
  else if (tab === 'sosmed') content = <SosmedPage onPay={onPay} onAddCart={onAddCart} />;
  else if (tab === 'premium') content = <PremiumPage onPay={onPay} onAddCart={onAddCart} />;
  else content = <ExtraPage tab={tab} user={user} onPay={onPay} showToast={p.showToast} />;

  return (
    <div className="min-h-screen bg-[#070709]">
      {/* TOPBAR FIXED */}
      <header className="fixed inset-x-0 top-0 z-50 flex h-16 items-center gap-3 border-b border-orange-500/20 bg-[#0a0a0d]/95 px-3 backdrop-blur-lg">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} aria-label="Toggle menu" className="rounded-lg p-2 hover:bg-white/10"><Menu className="h-6 w-6" /></button>
        <div className="hidden sm:block lg:hidden"><Logo small /></div>
        <div className="mx-auto flex w-full max-w-xl items-center gap-2 rounded-lg border border-orange-500/50 bg-black/50 px-3 shadow-[0_0_10px_rgba(255,106,0,0.2)] focus-within:border-orange-400">
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari layanan atau produk..."
            className="w-full bg-transparent py-2 text-sm outline-none placeholder:text-white/40" />
          {query ? <button onClick={() => setQuery('')} aria-label="Hapus pencarian"><X className="h-4 w-4 text-white/60" /></button> : <Search className="h-4 w-4 text-orange-400" />}
        </div>
        <button onClick={() => p.showToast('info', cartCount ? `${cartCount} item di keranjang` : 'Keranjang masih kosong')}
          className="relative hidden items-center gap-2 rounded-lg border border-orange-500/60 bg-orange-500/10 px-3 py-2 text-sm font-bold sm:flex">
          <ShoppingCart className="h-4 w-4 text-orange-300" /> Keranjang
          <span className="absolute -right-2 -top-2 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[11px] font-bold">{cartCount}</span>
        </button>
        <div className="hidden rounded-lg border border-orange-500/60 px-3 py-1 text-xs leading-tight sm:block">
          <div className="text-white/70">Saldo:</div><div className="font-bold text-orange-300">{rupiah(user.saldo)}</div>
        </div>
        <button onClick={() => navigate('profil')} className="flex items-center gap-2 rounded-lg px-1 py-1 hover:bg-white/5">
          <span className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-full border border-orange-500 bg-gradient-to-br from-orange-500 to-purple-700 text-sm font-black">
            {initial}
          </span>
          <span className="hidden text-left text-xs leading-tight md:block"><span className="block font-bold">{user.username}</span><span className="text-white/60">Welcome Back!</span></span>
          <ChevronDown className="hidden h-4 w-4 md:block" />
        </button>
      </header>

      {/* SIDEBAR */}
      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} />}
      <aside className={`fixed bottom-0 left-0 top-16 z-40 w-60 overflow-y-auto border-r border-orange-500/20 bg-[#0a0a0d] transition-transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="px-3 py-4"><Logo /></div>
        <nav className="px-3 pb-6">
          {groups.map((g) => (
            <div key={g.title} className="mb-3">
              <div className="mb-1 px-2 text-xs font-bold tracking-wider text-orange-400">{g.title}</div>
              {g.items.map((it) => {
                const active = it.key === tab && !query.trim();
                return (
                  <button key={it.key} onClick={() => (it.key === 'logout' ? onLogout() : navigate(it.key))}
                    className={`mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition ${
                      active ? 'border border-orange-400 bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-[0_0_14px_rgba(255,106,0,0.6)]' : 'text-white/80 hover:bg-white/10'}`}>
                    {it.icon}{it.label}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>
        <div className="border-t border-white/10 px-3 py-4 text-center">
          <Logo small />
          <p className="mt-1 text-xs text-white/60">Trusted • Fast • Affordable</p>
          <div className="mt-3 flex justify-center gap-3 text-white/70"><Instagram className="h-5 w-5" /><MessageCircle className="h-5 w-5" /><Send className="h-5 w-5" /><Youtube className="h-5 w-5" /></div>
        </div>
      </aside>

      <main className={`pt-16 transition-[padding] ${sidebarOpen ? 'lg:pl-60' : ''}`}>
        <div className="p-3 md:p-4">{content}</div>
        <footer className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-purple-500/20 px-4 py-3 text-xs text-white/60">
          <span><b className="italic text-white">NYXVO PROJECT</b> | Digital Market Premium</span>
          <span>© 2024 NYXVO PROJECT - All Rights Reserved.</span>
          <span>Made with <span className="text-red-500">♥</span> by NYXVO TEAM</span>
        </footer>
      </main>
    </div>
  );
}

/* ---------- Tombol Order/Keranjang ---------- */
function CartBtn({ item, onAddCart }: { item: Item; onAddCart: (i: Item) => void }) {
  return (
    <button onClick={() => onAddCart(item)} aria-label={`Tambah ${item.name} ke keranjang`}
      className="rounded-md border border-orange-500/60 bg-orange-500/15 p-1.5 text-orange-300 hover:bg-orange-500/30"><ShoppingCart className="h-4 w-4" /></button>
  );
}

/* ---------- Halaman Beranda ---------- */
function HomePage({ user, navigate, onPay, onAddCart, setQuery }: {
  user: UserRecord; navigate: (t: Tab) => void; onPay: (i?: Item) => void; onAddCart: (i: Item) => void; setQuery: (q: string) => void;
}) {
  const joinDate = new Date(user.createdAt).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
  const cats: { title: string; desc: string; tab: Tab }[] = [
    { title: 'SUNTIK SOSMED', desc: 'Tingkatkan performa sosial media kamu', tab: 'sosmed' },
    { title: 'NOKOS OTP', desc: 'Nomor virtual untuk verifikasi semua platform', tab: 'nokos' },
    { title: 'APLIKASI PREMIUM', desc: 'Aplikasi dan tools premium quality', tab: 'premium' },
  ];
  const steps = [
    { t: 'Pilih Layanan', d: 'Pilih layanan yang kamu butuhkan' },
    { t: 'Checkout', d: 'Isi data dan lakukan pembayaran' },
    { t: 'Proses', d: 'Sistem akan memproses pesanan otomatis' },
    { t: 'Selesai', d: 'Pesanan berhasil siap digunakan' },
  ];
  const sys: [string, string][] = [['Sistem', 'Automatic'], ['Metode Pembayaran', 'DANA, E-Wallet, Bank'], ['Proses', '1 - 5 Menit'], ['Status', 'Online 24/7']];

  return (
    <div className="grid gap-3 xl:grid-cols-[1fr_300px]">
      <div className="min-w-0 space-y-3">
        {/* Banner + Rank */}
        <div className="grid gap-3 lg:grid-cols-[1fr_280px] xl:grid-cols-1 2xl:grid-cols-[1fr_280px]">
          <AnimeArt src={ASSETS.hero} className={`rounded-xl ${neonBox}`}>
            <div className="relative z-10 flex min-h-[250px] flex-col items-center justify-center px-4 py-8 text-center md:items-end md:pr-10">
              <div className="md:text-center">
                <h1 className="text-3xl font-black italic drop-shadow-[0_0_12px_rgba(255,106,0,0.9)] md:text-4xl">NYXVO PROJECT</h1>
                <div className="text-2xl font-black text-orange-400 md:text-3xl">DIGITAL MARKET</div>
                <p className="mt-2 text-xs font-bold md:text-sm">SUNTIK ALL SOSMED • NOKOS OTP • APLIKASI PREMIUM</p>
                <p className="mt-1 text-xs font-bold text-orange-400 md:text-sm">PROSES OTOMATIS • MURAH • CEPAT • AMAN</p>
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  {[[<Users key="u" className="h-4 w-4 text-orange-400" />, '10K+ Pengguna'], [<Shield key="s" className="h-4 w-4 text-orange-400" />, '99.9% Uptime'], [<Timer key="t" className="h-4 w-4 text-orange-400" />, '24/7 Online'], [<ShieldCheck key="a" className="h-4 w-4 text-orange-400" />, '100% Aman']].map(([ic, tx], i) => (
                    <span key={i} className="flex items-center gap-1.5 rounded-lg border border-orange-500/50 bg-black/50 px-3 py-1.5 text-xs font-bold backdrop-blur">{ic}{tx as string}</span>
                  ))}
                </div>
              </div>
            </div>
          </AnimeArt>
          <AnimeArt src={ASSETS.rank} className={`rounded-xl border border-fuchsia-500/50 shadow-[0_0_18px_rgba(168,40,255,0.25)]`}>
            <div className="relative z-10 flex min-h-[200px] flex-col justify-end p-3">
              <div className="text-lg font-black">Halo, {user.username}</div>
              <div className="text-xs text-white/80">Selamat datang kembali di</div>
              <div className="text-sm font-black text-orange-400">NYXVO PROJECT</div>
              <div className="mt-2 flex items-center gap-3 rounded-lg border border-orange-500/60 bg-orange-500/10 px-3 py-2">
                <Crown className="h-7 w-7 text-orange-400" />
                <div className="text-xs leading-tight"><div className="text-white/70">RANK</div><div className="text-sm font-black">DEVELOPER</div></div>
              </div>
            </div>
          </AnimeArt>
        </div>

        {/* 3 Kartu Kategori */}
        <div className="grid gap-3 md:grid-cols-3">
          {cats.map((c) => (
            <AnimeArt key={c.title} src="" className="rounded-xl border border-purple-500/50 shadow-[0_0_16px_rgba(168,40,255,0.25)]">
              <div className="relative z-10 p-4">
                <h3 className="text-base font-black">{c.title}</h3>
                <p className="mt-1 max-w-[60%] text-xs text-white/80">{c.desc}</p>
                <button onClick={() => navigate(c.tab)} className="mt-4 rounded-md border border-orange-400 bg-orange-500/20 px-4 py-1.5 text-sm font-bold text-orange-200 hover:bg-orange-500/40">Lihat Layanan</button>
              </div>
            </AnimeArt>
          ))}
        </div>

        {/* Layanan Populer */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-black"><Flame className="h-5 w-5 text-orange-500" /> LAYANAN POPULER</h2>
            <button onClick={() => navigate('sosmed')} className="rounded-md border border-sky-400/60 bg-sky-500/10 px-3 py-1 text-sm font-semibold">Lihat Semua</button>
          </div>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {POPULAR.map((s) => (
              <div key={s.name} className={`rounded-xl border bg-black/40 p-4 ${s.color}`}>
                {s.icon}
                <div className="mt-2 text-sm font-semibold">{s.name}</div>
                <div className="mt-3 text-xs text-white/70">Start From</div>
                <div className="mt-1 flex items-center justify-between">
                  <span className="rounded border border-orange-500/60 bg-orange-500/10 px-2 py-0.5 text-sm font-bold text-orange-300">{rupiah(s.from)}</span>
                  <button onClick={() => { setQuery(s.name.split(' ')[0]); }} aria-label={`Cari ${s.name}`}
                    className="rounded-md border border-orange-500/60 bg-orange-500/15 p-1.5 text-orange-300"><ShoppingCart className="h-4 w-4" /></button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Produk Terbaru + Cara Order */}
        <div className="grid gap-3 lg:grid-cols-2">
          <div className="min-w-0 rounded-xl border border-orange-500/40 bg-black/40 p-3">
            <h3 className="mb-2 flex items-center gap-2 text-sm font-black"><Package className="h-4 w-4 text-orange-400" /> PRODUK TERBARU</h3>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[420px] text-left text-xs">
                <thead className="bg-white/5 text-white/60"><tr><th className="p-2">PRODUK</th><th className="p-2">KATEGORI</th><th className="p-2">HARGA</th><th className="p-2">STATUS</th><th className="p-2">AKSI</th></tr></thead>
                <tbody>
                  {PREMIUM.slice(0, 4).map((it) => (
                    <tr key={it.id} className="border-t border-white/5">
                      <td className="p-2 font-semibold">{it.name}</td>
                      <td className="p-2 font-semibold text-orange-400">Aplikasi Premium</td>
                      <td className="p-2">{rupiah(it.price)}</td>
                      <td className="p-2"><StatusBadge /></td>
                      <td className="p-2"><CartBtn item={it} onAddCart={onAddCart} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-xl border border-orange-500/40 bg-black/40 p-3">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-black"><Zap className="h-4 w-4 text-orange-400" /> CARA ORDER</h3>
            <div className="relative grid grid-cols-4 gap-2 text-center">
              <div className="absolute left-[12.5%] right-[12.5%] top-4 border-t-2 border-dashed border-orange-500/50" />
              {steps.map((s, i) => (
                <div key={s.t} className="relative">
                  <div className="mx-auto flex h-8 w-8 items-center justify-center rounded-full border-2 border-orange-400 bg-[#0d0e12] text-sm font-bold shadow-[0_0_10px_rgba(255,106,0,0.5)]">{i + 1}</div>
                  <div className="mt-2 text-xs font-bold">{s.t}</div>
                  <div className="mt-1 text-[10px] leading-tight text-white/60">{s.d}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Kolom kanan */}
      <div className="grid min-w-0 gap-3 md:grid-cols-2 xl:grid-cols-1 xl:content-start">
        <div className="rounded-xl border border-sky-400/50 bg-black/40 p-4 shadow-[0_0_16px_rgba(56,189,248,0.15)]">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-black"><BadgeCheck className="h-4 w-4 text-sky-300" /> STATISTIK AKUN</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-white/70">Total Order</span><b>128</b></div>
            <div className="flex justify-between"><span className="text-white/70">Saldo Akun</span><b className="text-emerald-400">{rupiah(user.saldo)}</b></div>
            <div className="flex justify-between"><span className="text-white/70">Member Sejak</span><b className="text-emerald-400">{joinDate}</b></div>
          </div>
        </div>
        <AnimeArt src={ASSETS.promo} className="rounded-xl border border-purple-500/50 shadow-[0_0_16px_rgba(168,40,255,0.3)]">
          <div className="relative z-10 flex min-h-[180px] flex-col items-center justify-end p-4 text-center">
            <div className="text-sm font-black">DEPOSIT SEKARANG</div>
            <div className="text-sm font-black text-orange-400">DAPATKAN BONUS</div>
            <div className="text-xl font-black">SALDO 10%</div>
            <button onClick={() => onPay()} className={`${btnOrange} mt-3 px-8 py-1.5 text-sm`}>DEPOSIT</button>
          </div>
        </AnimeArt>
        <div className="rounded-xl border border-white/15 bg-black/40 p-4 md:col-span-2 xl:col-span-1">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-black"><Settings className="h-4 w-4" /> INFO SISTEM</h3>
          <div className="space-y-2 text-xs">
            {sys.map(([k, v]) => <div key={k} className="flex justify-between gap-2"><span className="text-white/70">{k}</span><b className="text-right text-orange-300">{v}</b></div>)}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Halaman Nokos OTP ---------- */
function NokosPage({ onPay, onAddCart }: { onPay: (i?: Item) => void; onAddCart: (i: Item) => void }) {
  return (
    <section>
      <h2 className="mb-1 flex items-center gap-2 text-xl font-black"><Smartphone className="h-6 w-6 text-orange-400" /> Panel Nokos OTP</h2>
      <p className="mb-4 text-sm text-white/60">Nomor virtual untuk verifikasi. Garansi: 1x OTP / NO GARANSI.</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
        {NOKOS.map((it) => (
          <div key={it.id} className={`${glass} rounded-xl p-4 hover:border-orange-500/60`}>
            <div className="flex items-start justify-between gap-2">
              <h3 className="text-sm font-bold">{it.name}</h3>
              <StatusBadge />
            </div>
            <div className="mt-2 text-lg font-black text-orange-300">{rupiah(it.price)}</div>
            <div className="text-[11px] text-white/60">1x OTP / NO GARANSI{it.note ? ` • ${it.note}` : ''}</div>
            <div className="mt-3 flex items-center gap-2">
              <button onClick={() => onPay(it)} className={`${btnOrange} flex-1 py-1.5 text-sm`}>BELI</button>
              <CartBtn item={it} onAddCart={onAddCart} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- Halaman Suntik Sosmed ---------- */
function platformIcon(g: string): ReactNode {
  const c = 'h-5 w-5';
  if (g === 'Instagram') return <Instagram className={`${c} text-pink-400`} />;
  if (g === 'Youtube') return <Youtube className={`${c} text-red-500`} />;
  if (g === 'Telegram') return <Send className={`${c} text-sky-400`} />;
  if (g === 'Tiktok') return <Music2 className={`${c} text-cyan-300`} />;
  return <MessageCircle className={`${c} text-emerald-400`} />;
}

function SosmedPage({ onPay, onAddCart }: { onPay: (i?: Item) => void; onAddCart: (i: Item) => void }) {
  const platforms = Array.from(new Set(SOSMED.map((s) => s.group)));
  return (
    <section>
      <h2 className="mb-4 flex items-center gap-2 text-xl font-black"><CheckCircle2 className="h-6 w-6 text-orange-400" /> Panel Suntik Sosmed</h2>
      <div className="space-y-4">
        {platforms.map((pf) => (
          <div key={pf} className={`${glass} rounded-xl p-4`}>
            <h3 className="mb-3 flex items-center gap-2 font-black">{platformIcon(pf)} {pf}</h3>
            <div className="divide-y divide-white/5">
              {SOSMED.filter((s) => s.group === pf).map((it) => (
                <ServiceRow key={it.id} item={it} onPay={onPay} onAddCart={onAddCart} label="ORDER" />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ServiceRow({ item, onPay, onAddCart, label }: { item: Item; onPay: (i?: Item) => void; onAddCart: (i: Item) => void; label: string }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 py-2.5">
      <div className="min-w-0">
        <div className="text-sm font-semibold">{item.name}</div>
        <div className="text-xs text-white/50">{item.category}{item.note ? ` • ${item.note}` : ''}</div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-sm font-bold text-orange-300">{rupiah(item.price)}</span>
        <StatusBadge />
        <button onClick={() => onPay(item)} className={`${btnOrange} px-4 py-1.5 text-xs`}>{label}</button>
        <CartBtn item={item} onAddCart={onAddCart} />
      </div>
    </div>
  );
}

/* ---------- Halaman Aplikasi Premium ---------- */
function PremiumPage({ onPay, onAddCart }: { onPay: (i?: Item) => void; onAddCart: (i: Item) => void }) {
  return (
    <section>
      <h2 className="mb-1 flex items-center gap-2 text-xl font-black"><AppWindow className="h-6 w-6 text-orange-400" /> Panel Aplikasi Premium</h2>
      <p className="mb-4 text-sm text-white/60">Akun premium harga murah, siap pakai.</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {PREMIUM.map((it) => (
          <div key={it.id} className={`${glass} rounded-xl p-4 hover:border-orange-500/60`}>
            <div className="flex items-start justify-between gap-2"><h3 className="font-bold">{it.name}</h3><StatusBadge /></div>
            <div className="mt-2 text-xl font-black text-orange-300">{rupiah(it.price)}</div>
            <div className="mt-3 flex items-center gap-2">
              <button onClick={() => onPay(it)} className={`${btnOrange} flex-1 py-2 text-sm`}>BELI</button>
              <CartBtn item={it} onAddCart={onAddCart} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- Hasil Pencarian ---------- */
function SearchResults({ query, results, onPay, onAddCart }: { query: string; results: Item[]; onPay: (i?: Item) => void; onAddCart: (i: Item) => void }) {
  return (
    <section>
      <h2 className="mb-1 flex items-center gap-2 text-xl font-black"><Search className="h-6 w-6 text-orange-400" /> Hasil pencarian "{query.trim()}"</h2>
      <p className="mb-4 text-sm text-white/60">{results.length} layanan ditemukan.</p>
      {results.length === 0 ? (
        <div className={`${glass} rounded-xl p-8 text-center text-white/70`}>Tidak ada layanan yang cocok. Coba kata kunci lain, misalnya "Instagram" atau "WhatsApp".</div>
      ) : (
        <div className={`${glass} divide-y divide-white/5 rounded-xl px-4`}>
          {results.map((it) => <ServiceRow key={it.id} item={it} onPay={onPay} onAddCart={onAddCart} label={it.category === 'Suntik Sosmed' ? 'ORDER' : 'BELI'} />)}
        </div>
      )}
    </section>
  );
}

/* ---------- Halaman Extra & Akun ---------- */
function ExtraPage({ tab, user, onPay, showToast }: { tab: Tab; user: UserRecord; onPay: (i?: Item) => void; showToast: (t: ToastState['type'], m: string) => void }) {
  const joinDate = new Date(user.createdAt).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
  const refCode = `NYX-${user.username.toUpperCase().slice(0, 6)}`;

  if (tab === 'riwayat') {
    return (
      <section>
        <h2 className="mb-4 flex items-center gap-2 text-xl font-black"><FileText className="h-6 w-6 text-orange-400" /> Riwayat Pesanan</h2>
        <div className={`${glass} rounded-xl p-8 text-center text-white/70`}>Belum ada pesanan. Pesanan Anda akan muncul di sini setelah pembayaran terhubung.</div>
      </section>
    );
  }
  if (tab === 'deposit') {
    return (
      <section>
        <h2 className="mb-4 flex items-center gap-2 text-xl font-black"><Wallet className="h-6 w-6 text-orange-400" /> Deposit Saldo</h2>
        <div className={`${glass} ${neonBox} max-w-md rounded-xl p-6`}>
          <p className="text-sm text-white/70">Saldo saat ini</p>
          <div className="mb-4 text-3xl font-black text-orange-300">{rupiah(user.saldo)}</div>
          <p className="mb-4 text-sm text-white/70">Deposit sekarang dan dapatkan bonus saldo 10%.</p>
          <button onClick={() => onPay()} className={`${btnOrange} w-full py-3`}>DEPOSIT</button>
        </div>
      </section>
    );
  }
  if (tab === 'affiliate') {
    return (
      <section>
        <h2 className="mb-4 flex items-center gap-2 text-xl font-black"><Gift className="h-6 w-6 text-orange-400" /> Affiliate</h2>
        <div className={`${glass} max-w-md rounded-xl p-6`}>
          <p className="mb-3 text-sm text-white/70">Bagikan kode referral Anda kepada teman.</p>
          <div className="flex items-center justify-between rounded-lg border border-orange-500/50 bg-black/40 px-4 py-3">
            <span className="font-mono font-bold text-orange-300">{refCode}</span>
            <button aria-label="Salin kode" onClick={() => { try { void navigator.clipboard.writeText(refCode); showToast('ok', 'Kode referral disalin'); } catch { showToast('err', 'Gagal menyalin kode'); } }}><Copy className="h-4 w-4" /></button>
          </div>
        </div>
      </section>
    );
  }
  if (tab === 'profil') {
    return (
      <section>
        <h2 className="mb-4 flex items-center gap-2 text-xl font-black"><User className="h-6 w-6 text-orange-400" /> Profil Saya</h2>
        <div className={`${glass} max-w-md space-y-3 rounded-xl p-6 text-sm`}>
          <div className="flex justify-between"><span className="text-white/60">Username</span><b>{user.username}</b></div>
          <div className="flex justify-between"><span className="text-white/60">Saldo</span><b className="text-orange-300">{rupiah(user.saldo)}</b></div>
          <div className="flex justify-between"><span className="text-white/60">Bergabung</span><b>{joinDate}</b></div>
          <div className="flex justify-between"><span className="text-white/60">Rank</span><b>DEVELOPER</b></div>
        </div>
      </section>
    );
  }
  return (
    <section>
      <h2 className="mb-4 flex items-center gap-2 text-xl font-black"><Settings className="h-6 w-6 text-orange-400" /> Setting Akun</h2>
      <div className={`${glass} max-w-md rounded-xl p-6 text-sm text-white/70`}>Pengaturan akun (ubah kata sandi, notifikasi) akan tersedia setelah backend terhubung.</div>
    </section>
  );
}
